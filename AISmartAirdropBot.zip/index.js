
const TelegramBot = require('node-telegram-bot-api');
const { GoogleSpreadsheet } = require('google-spreadsheet');
const creds = require('./google-credentials.json');
const config = require('./config');

const bot = new TelegramBot(config.BOT_TOKEN, { polling: true });

const referralMap = new Map();

// تحميل Google Sheet
async function accessSheet() {
    const doc = new GoogleSpreadsheet(config.SHEET_ID);
    await doc.useServiceAccountAuth(creds);
    await doc.loadInfo();
    const sheet = doc.sheetsByIndex[0];
    return sheet;
}

// إرسال رسالة التحقق
bot.onText(/\/start(?:\s+(\d+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const referrerId = match[1];
    const username = msg.from.username || "unknown";

    let message = `👋 مرحبًا ${username}!

`;
    message += `للمشاركة في توزيع AISMART، يجب عليك:
`;
    message += `1️⃣ الاشتراك في القناة: @meAISMART
`;
    message += `2️⃣ متابعة حساب X: https://x.com/aismart374693 (سيتم التحقق يدويًا)
`;
    message += `3️⃣ إرسال عنوان محفظتك باستخدام /wallet
`;
    message += `4️⃣ دعوة أصدقائك باستخدام /invite

`;

    if (referrerId && referrerId !== chatId.toString()) {
        referralMap.set(chatId, referrerId);
        message += "🎁 لقد تم تسجيل الإحالة من الشخص الذي دعاك!
";
    }

    message += `
⚠️ تأكد من إتمام الخطوات بدقة.`;
    bot.sendMessage(chatId, message);
});

// تخزين المحفظة
bot.onText(/\/wallet (.+)/, async (msg, match) => {
    const wallet = match[1];
    const chatId = msg.chat.id;
    const username = msg.from.username || "unknown";
    const referredBy = referralMap.get(chatId) || "";

    const sheet = await accessSheet();
    await sheet.addRow({
        Username: username,
        TelegramID: chatId,
        Wallet: wallet,
        Referrals: 0,
        IsJoined: "pending",
        IsFollowed: "pending",
        Date: new Date().toLocaleString(),
    });

    bot.sendMessage(chatId, `✅ تم استلام عنوان محفظتك:
${wallet}`);
});

// إرسال رابط الإحالة
bot.onText(/\/invite/, (msg) => {
    const chatId = msg.chat.id;
    const username = msg.from.username || "user";
    const link = `https://t.me/AISmartAirdropBot?start=${chatId}`;
    bot.sendMessage(chatId, `📢 رابط الإحالة الخاص بك:
${link}`);
});

// حالة المستخدم
bot.onText(/\/status/, async (msg) => {
    const chatId = msg.chat.id;
    bot.sendMessage(chatId, "✅ سيتم التحقق من حالتك قريبًا من قبل الإدارة.");
});
