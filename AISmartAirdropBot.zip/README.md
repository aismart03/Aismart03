
# AISMART Airdrop Bot

This is the official Telegram bot for managing the AISMART token airdrop.

## Features
- Verify Telegram channel join
- Manual verification of Twitter follow
- Collect ERC-20 wallet addresses
- Generate referral links
- Store data in Google Sheets

## Setup

1. Replace `BOT_TOKEN` and `SHEET_ID` in `config.js`.
2. Add your Google service account credentials in `google-credentials.json`.
3. Run the bot:

```bash
npm install
npm start
```
